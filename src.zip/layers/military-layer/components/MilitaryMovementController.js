import * as Cesium from "cesium";
import { HexagonalGridManager } from "../../scene-layer/components/HexagonalGridManager";
import { SurfaceProfileManager } from "../../scene-layer/components/SurfaceProfileManager";
import { openGameStore } from "@/store";

/**
 * 军事单位移动控制器
 * 
 * 主要职责：
 * 1. 处理单位的移动路径规划
 * 2. 控制单位沿路径的平滑移动
 * 3. 基于地形计算移动速度
 * 4. 管理单位移动状态
 */
export class MilitaryMovementController {
  // 单例实例
  static #instance = null;
  
  /**
   * 获取单例实例
   * @param {Cesium.Viewer} viewer Cesium Viewer实例
   * @returns {MilitaryMovementController} 单例实例
   */
  static getInstance(viewer) {
    if (!MilitaryMovementController.#instance) {
      MilitaryMovementController.#instance = new MilitaryMovementController(viewer);
    }
    return MilitaryMovementController.#instance;
  }
  
  /**
   * 私有构造函数，避免外部直接创建实例
   * @param {Cesium.Viewer} viewer Cesium Viewer实例
   */
  constructor(viewer) {
    this.viewer = viewer;
    this.store = openGameStore();
    this.hexGridManager = HexagonalGridManager.getInstance(viewer);
    this.profileManager = SurfaceProfileManager.getInstance(viewer);
    
    // 活动单位移动状态：Map<forceId, MoveState>
    /**
     * 部队移动数据结构 (MoveState):
     * {
     *   path: string[],             // 六角格ID路径数组
     *   pathPoints: {              // 路径点坐标数组
     *     longitude: number,       // 经度
     *     latitude: number,        // 纬度
     *     height: number           // 高度（米）
     *   }[],
     *   forceInstance: {           // 部队实例引用
     *     force: Force,            // 部队数据
     *     unitInstanceMap: Map,    // 兵种实例映射
     *     pose: Object             // 部队位姿
     *   },
     *   startTime: number,         // 开始时间戳
     *   currentPathIndex: number,  // 当前路径段索引
     *   isMoving: boolean,         // 是否处于移动状态
     *   segments: [{               // 路径段数据
     *     from: {                  // 起点
     *       longitude: number,
     *       latitude: number,
     *       height: number
     *     },
     *     to: {                    // 终点
     *       longitude: number,
     *       latitude: number,
     *       height: number
     *     },
     *     heading: number,         // 该段朝向(弧度)
     *     duration: number,        // 该段持续时间(毫秒)
     *     startHeading: number,    // 起始朝向(弧度)
     *     endHeading: number       // 结束朝向(弧度)
     *   }],
     *   totalDuration: number,     // 总移动时间(毫秒)
     *   initialPose: {             // 初始位姿
     *     position: {              // 位置
     *       longitude: number,
     *       latitude: number,
     *       height: number
     *     },
     *     heading: number          // 朝向(弧度)
     *   },
     *   currentPose: {             // 当前位姿
     *     position: {              // 位置
     *       longitude: number,
     *       latitude: number,
     *       height: number
     *     },
     *     heading: number          // 朝向(弧度)
     *   }
     * }
     */
    this.movingForces = new Map();
    
    // 移动配置
    this.movementConfig = {
      baseSegmentDuration: 1500,  // 基础每段路径移动时间（毫秒）
      randomOffset: 10,          // 路径随机偏移范围（米）
      heightSpeedFactor: 0.5,    // 高度对速度的影响因子（越大影响越明显）
      minSpeedFactor: 0.6,       // 最低速度因子（保证高地形不会太慢）
      maxSpeedFactor: 1.5,       // 最高速度因子（保证低地形不会太快）
      heightThreshold: {         // 高度阈值
        low: 100,               // 低于此值使用最高速度
        high: 200               // 高于此值使用最低速度
      },
      easing: (t) => {           // 缓动函数 - 改为更平滑的三次贝塞尔曲线
        // 使用三次贝塞尔曲线实现更自然的加速和减速
        return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
      },
      heightOffset: 2,           // 模型离地高度
      turnConfig: {              // 转弯相关配置
        turnThreshold: 0.2,     // 转弯阈值：距离段终点多近开始转向下一段
        turnDuration: 0.3,      // 转弯时间占整段时间的比例
        initialTurnDuration: 0.2 // 起始转向时间占整段时间的比例
      }
    };
  }

  /**
   * 将部队沿指定路径移动
   * @param {string} forceId 部队ID
   * @param {Array<string>} path 路径点数组，包含 hexId
   * @param {Object} forceInstance 部队实例对象
   */
  moveForceAlongPath(forceId, path, forceInstance) {
    if (!path || path.length < 2) {
      console.error('移动路径无效:', path);
      return;
    }

    // 获取路径上所有六边形中心点的位置
    const pathPoints = [];
    for (const hexId of path) {
      const position = this._getHexCenterPosition(hexId);
      if (position) {
        pathPoints.push(position);
      }
    }
    
    if (pathPoints.length < 2) {
      console.error('无法计算路径点:', path);
      return;
    }

    // 计算起点和终点
    const startPoint = pathPoints[0];
    const endPoint = pathPoints[pathPoints.length - 1];
    
    // 初始方向为起点朝向第二个点
    const initialHeading = this._calculateDirection(startPoint, pathPoints[1]);
    
    // 终点方向为倒数第二个点朝向终点
    const finalHeading = this._calculateDirection(pathPoints[pathPoints.length - 2], endPoint);

    // 记录移动数据
    const moveData = {
      path: path,               // 六角格ID路径
      pathPoints: pathPoints,   // 路径点坐标
      forceInstance: forceInstance, // 部队实例
      startTime: Date.now(),    // 开始时间
      currentPathIndex: 0,      // 当前路径索引
      isMoving: true,           // 是否移动中
      segments: []              // 路径段数据
    };
    
    // 计算每个路径段的数据
    for (let i = 0; i < pathPoints.length - 1; i++) {
      const from = pathPoints[i];
      const to = pathPoints[i + 1];
      
      // 计算当前段的朝向（从当前点到下一点）
      const heading = this._calculateDirection(from, to);
      
      // 计算移动持续时间（考虑地形）
      const duration = this._calculateMovementDuration(path[i], path[i + 1]);
      
      moveData.segments.push({
        from: from,
        to: to,
        heading: heading,
        duration: duration,
        startHeading: i === 0 ? initialHeading : moveData.segments[i-1].heading, // 起始朝向
        endHeading: i === pathPoints.length - 2 ? finalHeading : heading // 结束朝向
      });
    }

    // 记录总持续时间
    moveData.totalDuration = moveData.segments.reduce((sum, segment) => sum + segment.duration, 0);
    
    // 记录部队初始位置和朝向
    moveData.initialPose = {
      position: { ...startPoint },
      heading: initialHeading
    };
    
    // 记录部队当前位置和朝向
    moveData.currentPose = {
      position: { ...startPoint },
      heading: initialHeading
    };

    // 添加到移动中的部队
    this.movingForces.set(forceId, moveData);
  }

  /**
   * 计算两点之间的方向角（弧度）
   * @private
   */
  _calculateDirection(point1, point2) {
    // 计算经纬度差
    const dLon = (point2.longitude - point1.longitude) * Math.cos((point1.latitude + point2.latitude) * Math.PI / 360);
    const dLat = point2.latitude - point1.latitude;
    
    // 计算方向角（0为正北，顺时针增加）
    let heading = Math.atan2(dLon, dLat);
    
    // 转换为0-2π范围
    if (heading < 0) heading += 2 * Math.PI;
    
    return heading;
  }

  /**
   * 计算模型的下一个位置
   * @param {string} forceId 部队ID
   * @returns {Object|null} 计算后的位置、朝向等信息
   */
  computeNextPosition(forceId) {
    const moveData = this.movingForces.get(forceId);
    if (!moveData || !moveData.isMoving) return null;

    const currentTime = Date.now();
    const elapsedTime = currentTime - moveData.startTime;
    
    // 如果超过总时间，则完成移动
    if (elapsedTime >= moveData.totalDuration) {
      // 到达终点，更新部队位置到最终位置
      const finalSegment = moveData.segments[moveData.segments.length - 1];
      moveData.currentPose = {
        position: { ...finalSegment.to },
        heading: finalSegment.endHeading
      };
      moveData.isMoving = false;
      
      // 更新部队在六角格中的位置
      const force = moveData.forceInstance.force;
      force.hexId = moveData.path[moveData.path.length - 1];
      
      return {
        position: { ...moveData.currentPose.position },
        direction: { heading: moveData.currentPose.heading }
      };
    }

    // 找到当前时间对应的路径段
    let accumulatedTime = 0;
    let currentSegmentIndex = 0;
    
    for (let i = 0; i < moveData.segments.length; i++) {
      const segmentDuration = moveData.segments[i].duration;
      if (elapsedTime < accumulatedTime + segmentDuration) {
        currentSegmentIndex = i;
        break;
      }
      accumulatedTime += segmentDuration;
    }
    
    const currentSegment = moveData.segments[currentSegmentIndex];
    const segmentElapsedTime = elapsedTime - accumulatedTime;
    const segmentProgress = segmentElapsedTime / currentSegment.duration;
    
    // 使用缓动函数计算平滑进度
    const smoothProgress = this.movementConfig.easing(segmentProgress);
    
    // 计算当前位置（三次贝塞尔插值，更加平滑）
    const position = this._calculateCurvedPosition(
      currentSegment.from,
      currentSegment.to,
      smoothProgress,
      currentSegmentIndex,
      moveData.segments
    );
    
    // 计算平滑过渡的朝向（提前转向）
    const heading = this._calculateSmoothHeading(
      currentSegment,
      smoothProgress,
      currentSegmentIndex,
      moveData.segments
    );
    
    // 更新部队当前位置和朝向
    moveData.currentPose = {
      position: position,
      heading: heading
    };
    
    // 记录当前所在的路径段索引
    moveData.currentPathIndex = currentSegmentIndex;
    
    return {
      position: position,
      direction: { heading: moveData.currentPose.heading }
    };
  }

  /**
   * 计算路径上的曲线位置（考虑前后点的影响）
   * @private
   */
  _calculateCurvedPosition(from, to, progress, segmentIndex, allSegments) {
    // 直线插值作为基础
    const position = {
      longitude: from.longitude + (to.longitude - from.longitude) * progress,
      latitude: from.latitude + (to.latitude - from.latitude) * progress,
      height: from.height + (to.height - from.height) * progress
    };

    // 如果是第一段或最后一段，仅做直线插值
    if (segmentIndex === 0 || segmentIndex === allSegments.length - 1) {
      return position;
    }

    // 对中间段，考虑前后点位置，实现更平滑的过渡
    // 简化为微小的垂直偏移，模拟弹道效果
    const segmentLength = Math.sqrt(
      Math.pow((to.longitude - from.longitude) * 111320 * Math.cos(from.latitude * Math.PI / 180), 2) +
      Math.pow((to.latitude - from.latitude) * 111320, 2)
    );
    
    // 根据段长度调整偏移量
    const maxOffset = Math.min(5, segmentLength * 0.05); // 最大偏移量，米
    
    // 在中间点处达到最大偏移
    const verticalOffset = Math.sin(progress * Math.PI) * maxOffset;
    
    // 应用垂直偏移
    position.height += verticalOffset;
    
    return position;
  }

  /**
   * 计算平滑的转向角度
   * @private
   */
  _calculateSmoothHeading(currentSegment, progress, segmentIndex, allSegments) {
    const { turnConfig } = this.movementConfig;
    
    // 获取当前段的起始和结束朝向
    let startHeading = currentSegment.startHeading;
    let endHeading = currentSegment.endHeading;
    
    // 处理跨越0度/360度的特殊情况
    if (Math.abs(endHeading - startHeading) > Math.PI) {
      if (startHeading < endHeading) {
        startHeading += 2 * Math.PI;
      } else {
        endHeading += 2 * Math.PI;
      }
    }
    
    // 基本进度比例
    let headingProgress = progress;
    
    // 处理特殊转向情况
    if (segmentIndex === 0 && progress < turnConfig.initialTurnDuration) {
      // 起始段快速转向
      headingProgress = progress / turnConfig.initialTurnDuration;
    } else if (progress > (1 - turnConfig.turnThreshold) && segmentIndex < allSegments.length - 1) {
      // 接近段尾，开始提前转向下一段
      const nextSegment = allSegments[segmentIndex + 1];
      
      // 计算过渡进度
      const transitionProgress = (progress - (1 - turnConfig.turnThreshold)) / turnConfig.turnThreshold;
      
      // 提前部分转向下一段的朝向
      let nextHeading = nextSegment.heading;
      
      // 同样处理跨越0度/360度的情况
      if (Math.abs(nextHeading - endHeading) > Math.PI) {
        if (endHeading < nextHeading) {
          endHeading += 2 * Math.PI;
        } else {
          nextHeading += 2 * Math.PI;
        }
      }
      
      // 在当前段结束朝向和下一段朝向之间插值
      endHeading = endHeading + transitionProgress * (nextHeading - endHeading);
    }
    
    // 计算最终朝向
    const heading = startHeading + (endHeading - startHeading) * headingProgress;
    
    // 确保返回在 0-2π 范围内
    return heading % (2 * Math.PI);
  }

  /**
   * 获取部队当前的移动状态
   * @param {string} forceId 部队ID
   * @returns {Object|null} 移动数据
   */
  getMovementData(forceId) {
    return this.movingForces.get(forceId) || null;
  }

  /**
   * 清理资源
   */
  dispose() {
    this.movingForces.clear();
    MilitaryMovementController.#instance = null;
  }

  /**
   * 清理已完成移动的部队
   * 返回是否有部队在移动
   * @returns {boolean} 是否还有部队在移动
   */
  cleanupFinishedMovements() {
    let hasMovingForces = false;
    
    this.movingForces.forEach((data, forceId) => {
      if (!data.isMoving) {
        this.movingForces.delete(forceId);
      } else {
        hasMovingForces = true;
      }
    });
    
    return hasMovingForces;
  }

  /**
   * 计算模型的朝向矩阵
   * @param {Object} position 位置
   * @param {Object} direction 方向
   * @param {Object} localOffset 局部偏移
   * @returns {Cesium.Matrix4} 变换矩阵
   */
  computeOrientedModelMatrix(position, direction, localOffset = { x: 0, y: 0 }) {
    if (!position) return Cesium.Matrix4.IDENTITY;

    // 旋转局部偏移（基于部队朝向）
    const rotatedOffset = this._rotateOffset(localOffset.x, localOffset.y, direction.heading);

    // 将局部偏移转换为经纬度偏移
    const metersPerDegree = 111320;
    const lonOffset = rotatedOffset.x / (metersPerDegree * Math.cos(position.latitude * Math.PI / 180));
    const latOffset = rotatedOffset.y / metersPerDegree;

    // 计算最终位置
    const worldPosition = Cesium.Cartesian3.fromDegrees(
      position.longitude + lonOffset,
      position.latitude + latOffset,
      position.height
    );

    // 创建基础ENU矩阵
    const enuMatrix = Cesium.Transforms.eastNorthUpToFixedFrame(worldPosition);
    
    // 应用朝向旋转
    const rotationMatrix = Cesium.Matrix4.fromRotationTranslation(
      Cesium.Matrix3.fromRotationZ(direction.heading),
      Cesium.Cartesian3.ZERO
    );
    
    // 将旋转应用到ENU矩阵
    return Cesium.Matrix4.multiply(enuMatrix, rotationMatrix, new Cesium.Matrix4());
  }

  /**
   * 根据方向旋转局部偏移坐标
   * @private
   */
  _rotateOffset(x, y, heading) {
    const cos = Math.cos(heading);
    const sin = Math.sin(heading);
    return {
      x: x * cos - y * sin,
      y: x * sin + y * cos
    };
  }

  /**
   * 根据六角格高度计算移动持续时间
   * @private
   * @param {string} fromHexId 起始六角格ID
   * @param {string} toHexId 目标六角格ID
   * @returns {number} 移动持续时间（毫秒）
   */
  _calculateMovementDuration(fromHexId, toHexId) {
    const fromHex = this.store.getHexCellById(fromHexId);
    const toHex = this.store.getHexCellById(toHexId);
    
    if (!fromHex || !toHex) {
      return this.movementConfig.baseSegmentDuration;
    }
    
    // 获取两个六角格的平均高度
    const fromElevation = fromHex.terrainAttributes?.elevation || 0;
    const toElevation = toHex.terrainAttributes?.elevation || 0;
    const avgElevation = (fromElevation + toElevation) / 2;
    
    // 根据高度映射速度因子（高度越高，速度越慢）
    let speedFactor = 1;
    const { heightThreshold, heightSpeedFactor, minSpeedFactor, maxSpeedFactor } = this.movementConfig;
    
    if (avgElevation <= heightThreshold.low) {
      // 低于阈值使用最快速度
      speedFactor = maxSpeedFactor;
    } else if (avgElevation >= heightThreshold.high) {
      // 高于阈值使用最慢速度
      speedFactor = minSpeedFactor;
    } else {
      // 在阈值之间线性插值
      const t = (avgElevation - heightThreshold.low) / (heightThreshold.high - heightThreshold.low);
      speedFactor = maxSpeedFactor - t * (maxSpeedFactor - minSpeedFactor) * heightSpeedFactor;
    }
    
    // 应用速度因子计算持续时间（速度因子越大，时间越短）
    return this.movementConfig.baseSegmentDuration / speedFactor;
  }

  /**
   * 获取六角格中心位置
   * @private
   */
  _getHexCenterPosition(hexId) {
    const hex = this.store.getHexCellById(hexId);
    if (!hex) return null;
    
    const center = hex.getCenter();
    return {
      longitude: center.longitude,
      latitude: center.latitude,
      height: center.height + this.movementConfig.heightOffset
    };
  }
} 