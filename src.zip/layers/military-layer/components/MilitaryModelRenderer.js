import * as Cesium from "cesium";
import { reactive } from 'vue';
import { openGameStore } from '@/store';
import { HexConfig } from '@/config/GameConfig';
import { HexForceMapper } from '@/utils/HexForceMapper';
// eslint-disable-next-line no-unused-vars
import { MilitaryModelLoader } from "./MilitaryModelLoader";
import { MilitaryMovementController } from "./MilitaryMovementController";

/**
 * 军事模型渲染器
 * 
 * 主要职责：
 * 1. 管理部队模型的实例化和渲染（一个部队包含多个兵种模型）
 * 2. 处理部队位置更新和 LOD 切换
 * 3. 维护部队在六角格内的排布
 */
export class MilitaryModelRenderer {
  // 单例实例
  static #instance = null;
  
  /**
   * 获取单例实例
   * @param {Cesium.Viewer} viewer Cesium Viewer实例
   * @param {MilitaryModelLoader} loader 模型加载器
   * @returns {MilitaryModelRenderer} 单例实例
   */
  static getInstance(viewer, loader) {
    if (!MilitaryModelRenderer.#instance) {
      MilitaryModelRenderer.#instance = new MilitaryModelRenderer(viewer, loader);
    }
    return MilitaryModelRenderer.#instance;
  }
  
  /**
   * 私有构造函数，避免外部直接创建实例
   * @param {Cesium.Viewer} viewer Cesium Viewer实例
   * @param {MilitaryModelLoader} loader 模型加载器
   */
  constructor(viewer, loader) {
    this.viewer = viewer;
    this.loader = loader;
    this.store = openGameStore();
    
    // 初始化移动控制器
    this.movementController = MilitaryMovementController.getInstance(viewer);
    
    // forceInstanceMap: Map<forceId, forceInstance>
    // forceInstance: {
    //   force: Force, —— 部队
    //   unitInstanceMap: Map<unitInstanceId, unitInstance>, —— 兵种实例集合
    //   pose: { position: { longitude, latitude, height }, heading: number } —— 部队位置和朝向
    // }
    // unitInstanceId: `${forceId}_${unitId}_${index}`
    // unitInstance: {
    //   currentModel: Cesium.Model, —— 当前显示的模型实例
    //   currentLOD: number, —— 当前 LOD 级别
    //   modelTemplate: modelTemplate, —— 兵种模型模版
    //   localOffset: { x, y } —— 兵种在部队内的相对偏移
    // }
    this.forceInstanceMap = reactive(new Map());
    
    this._updateHandle = null;

    // 部队排布配置
    this.layoutConfig = {
      // 环形布局（少量部队）
      ringLayout: {
        maxCount: 6,          // 最大使用环形的部队数
        radiusScale: 0.4      // 环半径 = 六角格半径 * 此系数
      },
      // 网格布局（中等数量）
      gridLayout: {
        maxCount: 9,          // 最大使用网格的部队数
        scale: 0.7           // 网格整体缩放系数
      },
      // 部队内兵种布局
      unitLayout: {
        spacing: 5,          // 兵种间距（米）
        maxRow: 3           // 每行最多放置的兵种数
      },
      // 通用配置
      heightOffset: 2,        // 模型离地高度
    };
  }

  /**
   * 强制重新渲染所有部队的模型
   */
  renderAllForces() {
    this.store.getForces().forEach(force => {
      // 先移除所有部队实例
      this._removeForceInstanceById(force.forceId);
      // 再创建新的部队实例
      this._createForceInstance(force);
    });
    this._startUpdateLoop();
  }

  /**
   * 处理部队数量变化（新增或删除部队）
   */
  handleForcesChange(newForceIds, oldForceIds) {
    // 添加新部队
    newForceIds.forEach(id => {
      if (!this.forceInstanceMap.has(id)) {
        const force = this.store.getForceById(id);
        if (force) this._createForceInstance(force);
      }
    });

    // 移除旧部队
    oldForceIds.forEach(id => {
      if (!newForceIds.includes(id)) {
        this._removeForceInstanceById(id);
      }
    });
  }

  /**
   * 移动部队沿着路径前进
   * @param {string} forceId 部队ID
   * @param {string[]} path 路径（六角格ID数组）
   */
  moveForceAlongPath(forceId, path) {
    if (!path || path.length < 2) {
      console.warn("路径过短，无法进行移动");
      return;
    }
    
    const forceInstance = this.forceInstanceMap.get(forceId);
    if (!forceInstance) {
      console.error(`未找到部队实例: ${forceId}`);
      return;
    }
    
    // 委托给移动控制器处理
    this.movementController.moveForceAlongPath(forceId, path, forceInstance);
    
    // 确保更新循环已启动
    this._startUpdateLoop();
  }

  /**
   * 清理所有实例
   */
  dispose() {
    if (this._updateHandle) {
      this.viewer.scene.postUpdate.removeEventListener(this._updateHandle);
      this._updateHandle = null;
    }
    
    this.forceInstanceMap.forEach(forceInstance => {
      forceInstance.unitInstanceMap.forEach(unitInstance => {
        this.viewer.scene.primitives.remove(unitInstance.currentModel);
      });
    });
    this.forceInstanceMap.clear();
    
    // 清理移动控制器
    this.movementController.dispose();
    
    // 清理单例
    MilitaryModelRenderer.#instance = null;
  }

  /**
   * 创建部队实例（包含多个兵种模型）
   * @private
   */
  async _createForceInstance(force) {
    try {
      const position = this._computeForcePosition(force);
      const forceInstance = {
        force: force,
        unitInstanceMap: new Map(),
        pose: {
          position: position,
          heading: 0 // 初始朝向为0
        }
      };

      // 为每个兵种创建实例
      for (const comp of force.composition) {
        const unit = this.store.getUnitById(comp.unitId);
        if (!unit || !unit.renderingKey) continue;

        const modelTemplate = await this.loader.getModelTemplate(unit.renderingKey);
        const baseModel = modelTemplate.lodModels[0].model;
        
        // 计算该兵种在部队内的相对位置
        const localOffset = this._computeUnitLocalOffset(
          force.composition.indexOf(comp),
          force.composition.length
        );

        // 创建实例
        for (let i = 0; i < comp.unitCount; i++) {
          const currentModel = baseModel.clone();
          const unitInstance = {
            currentModel: currentModel, // 当前显示的模型实例
            currentLOD: 0,
            modelTemplate: modelTemplate, // 兵种模型模版
            localOffset: {
              x: localOffset.x + (Math.random() - 0.5) * 2, // 添加随机微偏移
              y: localOffset.y + (Math.random() - 0.5) * 2
            }
          };

          // 设置初始位置
          currentModel.modelMatrix = this._computeUnitModelMatrix(
            forceInstance.pose,
            unitInstance.localOffset
          );
          currentModel.allowPicking = true;
          
          this.viewer.scene.primitives.add(currentModel);
          
          // 使用 forceId_unitId_index 作为 key
          const unitInstanceId = `${force.forceId}_${comp.unitId}_${i}`;
          forceInstance.unitInstanceMap.set(unitInstanceId, unitInstance);
        }
      }

      this.forceInstanceMap.set(force.forceId, forceInstance);
    } catch (error) {
      console.error(`创建部队实例失败: ${force.forceId}`, error);
    }
  }

  /**
   * 移除部队实例
   * @private
   */
  _removeForceInstanceById(forceId) {
    const forceInstance = this.forceInstanceMap.get(forceId);
    if (forceInstance) {
      forceInstance.unitInstanceMap.forEach(unitInstance => {
        this.viewer.scene.primitives.remove(unitInstance.currentModel);
      });
      this.forceInstanceMap.delete(forceId);
    }
  }

  /**
   * 启动更新循环，每帧执行一次
   * @private
   */
  _startUpdateLoop() {
    if (this._updateHandle) return;
    
    this._updateHandle = this.viewer.scene.postUpdate.addEventListener(() => {      
      // 更新所有部队
      this.forceInstanceMap.forEach((forceInstance, forceId) => {
        // 首先检查部队是否在移动中（不计算位置，只检查状态）
        const isMoving = this.movementController.movingForces.has(forceId);
        
        if (isMoving) {
          // 移动中的部队：计算新位置并更新
          const nextPose = this.movementController.computeNextPosition(forceId);
          if (nextPose) {
            // 更新部队位置和朝向
            forceInstance.pose = {
              position: nextPose.position,
              heading: nextPose.direction.heading
            };
            // 更新部队实例中各兵种模型的位置和朝向
            this._updateMovingModels(forceInstance);
          }
        }
        else {
          // 静止部队：更新LOD
          this._updateModelLOD(forceInstance);
        }
      });

      // 清理已完成移动的部队
      this.movementController.cleanupFinishedMovements();
    });
  }

  /**
   * 更新模型LOD（用于静止部队）
   * @private
   */
  _updateModelLOD(forceInstance) {
    const cameraPos = this.viewer.scene.camera.positionWC;

    forceInstance.unitInstanceMap.forEach(unitInstance => {
      // 获取当前模型位置用于计算与相机的距离
      const modelPos = Cesium.Matrix4.getTranslation(
        unitInstance.currentModel.modelMatrix,
        new Cesium.Cartesian3()
      );
      const distance = Cesium.Cartesian3.distance(cameraPos, modelPos);
      
      // 选择合适的 LOD 级别
      let targetLOD = 0;
      unitInstance.modelTemplate.lodModels.forEach((level, index) => {
        if (distance >= level.distance) {
          targetLOD = index;
        }
      });
      
      // 如果需要切换 LOD，并更新模型重新载入 primitives
      if (targetLOD !== unitInstance.currentLOD) {
        const targetModel = unitInstance.modelTemplate.lodModels[targetLOD].model.clone();
        // 保持原有位置
        targetModel.modelMatrix = unitInstance.currentModel.modelMatrix;
        targetModel.allowPicking = true;
        
        this.viewer.scene.primitives.remove(unitInstance.currentModel);
        this.viewer.scene.primitives.add(targetModel);
        
        unitInstance.currentModel = targetModel;
        unitInstance.currentLOD = targetLOD;
      }
    });
  }

  /**
   * 更新移动中的模型位置和朝向
   * @private
   */
  _updateMovingModels(forceInstance) {
    forceInstance.unitInstanceMap.forEach(unitInstance => {
      // 更新位置和朝向
      unitInstance.currentModel.modelMatrix = this.movementController.computeOrientedModelMatrix(
        forceInstance.pose.position,
        { heading: forceInstance.pose.heading },
        unitInstance.localOffset
      );
    });
  }

  /**
   * 计算部队在六角格内的位置
   * @private
   */
  _computeForcePosition(force) {
    const hex = this.store.getHexCellById(force.hexId);
    if (!hex) return null;

    const center = hex.getCenter();
    // 从 HexForceMapper 获取部队列表
    const forces = HexForceMapper.getForcesByHexId(force.hexId);
    const index = forces.indexOf(force.forceId);
    
    // 简化为随机布局，但尽量减少重叠
    const maxRandomOffset = HexConfig.radius * 0.7; // 最大随机偏移为六角格半径的70%
    const forceRadius = HexConfig.radius * 0.15; // 部队占据的半径
    const maxAttempts = 15; // 最大尝试次数
    const existingPositions = []; // 已经存在的位置
    
    // 获取已有部队的位置
    for (let i = 0; i < index; i++) {
      const otherForceId = forces[i];
      const otherForce = this.forceInstanceMap.get(otherForceId);
      if (otherForce && otherForce.pose && otherForce.pose.position) {
        existingPositions.push({
          x: (otherForce.pose.position.longitude - center.longitude) * 111320 * Math.cos(center.latitude * Math.PI / 180),
          y: (otherForce.pose.position.latitude - center.latitude) * 111320
        });
      }
    }
    
    // 随机散列分布 + 避免重叠
    let offsetX = 0, offsetY = 0;
    let foundValidPosition = false;
    
    for (let attempt = 0; attempt < maxAttempts && !foundValidPosition; attempt++) {
      // 随机选择六角格内的位置
      const randomAngle = Math.random() * Math.PI * 2;
      const randomRadius = maxRandomOffset * Math.sqrt(Math.random()); // 使用sqrt确保分布均匀
      
      const candidateX = randomRadius * Math.cos(randomAngle);
      const candidateY = randomRadius * Math.sin(randomAngle);
      
      // 检查是否与已有部队重叠
      let hasOverlap = false;
      for (const pos of existingPositions) {
        const dx = candidateX - pos.x;
        const dy = candidateY - pos.y;
        const distanceSquared = dx * dx + dy * dy;
        
        if (distanceSquared < 3 * forceRadius * forceRadius) { // 使用3倍半径平方作为最小距离
          hasOverlap = true;
          break;
        }
      }
      
      if (!hasOverlap) {
        offsetX = candidateX;
        offsetY = candidateY;
        foundValidPosition = true;
      }
    }
    
    // 如果无法找到不重叠的位置，就使用随机位置
    if (!foundValidPosition) {
      const randomAngle = Math.random() * Math.PI * 2;
      const randomRadius = maxRandomOffset * Math.sqrt(Math.random());
      
      offsetX = randomRadius * Math.cos(randomAngle);
      offsetY = randomRadius * Math.sin(randomAngle);
    }

    // 将米偏移转换为经纬度偏移
    const metersPerDegree = 111320;
    const lonOffset = offsetX / (metersPerDegree * Math.cos(center.latitude * Math.PI / 180));
    const latOffset = offsetY / metersPerDegree;

    return {
      longitude: center.longitude + lonOffset,
      latitude: center.latitude + latOffset,
      height: center.height + this.layoutConfig.heightOffset
    };
  }

  /**
   * 计算兵种在部队内的相对偏移
   * @private
   */
  _computeUnitLocalOffset(index, total) {
    // 使用环形或网格布局计算兵种在部队内的位置
    const spacing = this.layoutConfig.unitLayout.spacing;
    
    // 根据总数选择阵型布局
    if (total <= 3) {
      // 三角阵型（少量兵种）
      const angles = [0, 2 * Math.PI / 3, 4 * Math.PI / 3];
      const radius = spacing * 0.8;
      const angle = angles[index % angles.length];
      return {
        x: radius * Math.cos(angle),
        y: radius * Math.sin(angle)
      };
    } else if (total <= 6) {
      // 环形布局（中等数量兵种）
      const radius = spacing * 1.2;
      const angle = (2 * Math.PI * index) / total;
      // 添加少许随机性
      const randomFactor = 0.1;
      const randomRadius = radius * (1 + (Math.random() - 0.5) * randomFactor);
      return {
        x: randomRadius * Math.cos(angle),
        y: randomRadius * Math.sin(angle)
      };
    } else {
      // 战术方阵布局（大量兵种）
      const { maxRow } = this.layoutConfig.unitLayout;
      const cols = Math.min(maxRow, Math.ceil(Math.sqrt(total)));
      const rows = Math.ceil(total / cols);
      
      const row = Math.floor(index / cols);
      const col = index % cols;
      
      // 构建略微不规则的方阵（更真实）
      const xJitter = (Math.random() - 0.5) * spacing * 0.2;
      const yJitter = (Math.random() - 0.5) * spacing * 0.2;
      
      return {
        x: (col - (cols - 1) / 2) * spacing + xJitter,
        y: (row - (rows - 1) / 2) * spacing + yJitter
      };
    }
  }

  /**
   * 计算兵种模型的最终变换矩阵（适用于静止部队）
   * @private
   */
  _computeUnitModelMatrix(forcePose, localOffset) {
    if (!forcePose?.position) return Cesium.Matrix4.IDENTITY;

    // 旋转局部偏移（基于部队朝向）
    const rotatedOffset = this._rotateOffset(localOffset.x, localOffset.y, forcePose.heading || 0);

    // 将局部偏移转换为经纬度偏移
    const forcePosition = forcePose.position;
    const metersPerDegree = 111320;
    const lonOffset = rotatedOffset.x / (metersPerDegree * Math.cos(forcePosition.latitude * Math.PI / 180));
    const latOffset = rotatedOffset.y / metersPerDegree;

    // 构建最终位置
    const position = Cesium.Cartesian3.fromDegrees(
      forcePosition.longitude + lonOffset,
      forcePosition.latitude + latOffset,
      forcePosition.height
    );

    // 创建基础ENU矩阵
    const enuMatrix = Cesium.Transforms.eastNorthUpToFixedFrame(position);
    
    // 如果有朝向，应用旋转
    if (forcePose.heading !== undefined) {
      // 创建旋转矩阵
      const rotationMatrix = Cesium.Matrix4.fromRotationTranslation(
        Cesium.Matrix3.fromRotationZ(forcePose.heading),
        Cesium.Cartesian3.ZERO
      );
      
      // 将旋转应用到ENU矩阵
      Cesium.Matrix4.multiply(enuMatrix, rotationMatrix, enuMatrix);
    }

    return enuMatrix;
  }

  /**
   * 根据方向旋转局部偏移坐标
   * @private
   */
  _rotateOffset(x, y, heading) {
    const cos = Math.cos(heading);
    const sin = Math.sin(heading);
    return {
      x: x * cos - y * sin,
      y: x * sin + y * cos
    };
  }
}
